package ru.sfedu.maven1;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import ru.sfedu.maven1.enums.DealStatus;

public class Main {

  private static Logger log = LogManager.getLogger(Main.class);

  public static void main(String args[]) {

//    System.out.println(DealStatus.AD);
//    System.out.println(DealStatus.AD.getMessage());

  }
}
