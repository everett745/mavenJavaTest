package ru.sfedu.maven1.enums;

public enum DealModel {
  PRIVATE,
  PUBLIC
}
