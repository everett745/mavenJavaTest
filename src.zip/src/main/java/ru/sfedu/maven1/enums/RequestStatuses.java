package ru.sfedu.maven1.enums;

public enum RequestStatuses {
  SUCCESS,
  FAILED,
  NOT_FOUNDED,
}
