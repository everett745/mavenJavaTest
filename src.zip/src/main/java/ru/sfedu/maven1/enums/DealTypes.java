package ru.sfedu.maven1.enums;

public enum DealTypes {
  PURCHASE,
  SALE
}
