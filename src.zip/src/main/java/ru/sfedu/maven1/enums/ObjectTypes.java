package ru.sfedu.maven1.enums;

public enum ObjectTypes {
  PRIVATE_HOUSE,
  BUILDING,
  LAND
}
