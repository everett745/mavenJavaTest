import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;


public class MainTest {

  private static final Logger log = LogManager.getLogger(ru.sfedu.maven1.Main.class);

  @Test
  void test(){

  }
}
