package ru.sfedu.maven1.dataProviders;

import org.junit.Test;
import ru.sfedu.maven1.TestBase;

public class DataProviderXMLTest extends TestBase {

  @Test
  public void testInsertUserSuccess() throws Exception {}

  @Test
  public void testInsertUserFailure() throws Exception {}

}
